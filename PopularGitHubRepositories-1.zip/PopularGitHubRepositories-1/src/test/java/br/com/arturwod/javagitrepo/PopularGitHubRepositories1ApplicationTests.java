package br.com.arturwod.javagitrepo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PopularGitHubRepositories1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
