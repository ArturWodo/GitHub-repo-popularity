package br.com.arturwod.javagitrepo.controller;

import java.util.ArrayList;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jayway.jsonpath.Configuration;

/**
 * Controllerfor test
 * 
 * @author Artur Wodołazski
 *
 */
/*@RestController
@RequestMapping("/api/example/")
public class ControlGitRepo {
	
	@GetMapping("/repo")
	public ResponseEntity<String> get() {
		return ResponseEntity.ok("githubtest!");
	}
*/

@CrossOrigin("http://localhost:4100")
@RequestMapping(method = RequestMethod.GET, value = "/getstarsperlang/{username}")
public @ResponseBody ArrayList<Object> getStarsPerLang(@PathVariable String username, RestTemplate restTemplate) {

    ArrayList<Object> output = new ArrayList<>();
    ArrayList<String> languages = new ArrayList<>();
    ArrayList<Integer> num_stars = new ArrayList<>();
    ArrayList<Integer> num_forks = new ArrayList<>();

    String URL = "https://api.github.com/users/" + username + "/starred?client_id=" + Configuration.client_id
            + "&client_repo=" + Configuration.client_repo;

    restTemplate = new RestTemplate();
    headers = new HttpHeaders();
    headers.set("User-Agent", "profile-analyzer");
    HttpEntity<String> entity = new HttpEntity<>("parameters", headers);

    ResponseEntity<Repo[]> repos = restTemplate.exchange(URL, HttpMethod.GET, entity, Repo[].class);

    Repo[] arr = repos.getBody();

    for (Repo repo : arr) {
        languages.add(repo.getLanguage());
    }
    score=num_stars*1+num_forks;

    languages = new ArrayList<String>(new LinkedHashSet<String>(languages));

   
    for(String language : languages) {
        int count = 0;
        for(Repository repo: repositories) {
                     if(Objects.equals(repo.getLanguage(), language)){
                count++;
            }
        }
        num_stars.add(count);
    }

    output.add(languages);
    output.add(num_stars);
    output.add(num_forks);
    score=num_stars*1+num_forks*2;
    if (score>=500) {
    	
    	
    	return output;
    }
    
  

}
}

