package br.com.arturwod.javagitrepo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PopularGitHubRepositories1Application {

	public static void main(String[] args) {
		SpringApplication.run(PopularGitHubRepositories1Application.class, args);
	}

}
